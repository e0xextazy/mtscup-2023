"""The main module, which includes the AutoML class, blenders and ready-made presets."""

__all__ = ["base", "presets", "blend"]
