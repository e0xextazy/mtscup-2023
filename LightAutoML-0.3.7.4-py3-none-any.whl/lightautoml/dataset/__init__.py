"""Provides an internal interface for working with data."""

__all__ = ["base", "roles", "np_pd_dataset", "utils"]
